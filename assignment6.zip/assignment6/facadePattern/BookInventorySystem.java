package assignment6.facadePattern;

import java.util.ArrayList;
import java.util.List;

public class BookInventorySystem {
    private List<Book> books;

    public BookInventorySystem() {
        // Initialize the list of books
        this.books = new ArrayList<>();
        // Populate books (this could be done in various ways, e.g., loading from a database)
        initializeBooks();
    }

    private void initializeBooks() {
        // Add sample books to the inventory
        books.add(new Book("1", "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Book("2", "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book("3", "1984", "George Orwell"));
        // Add more books as needed
    }

    // Method to check if a book is available
    public boolean isAvailable(String bookId) {
        for (Book book : books) {
            if (book.getBookId().equals(bookId)) {
                return true;
            }
        }
        return false;
    }

    // Method to update the availability status of a book
    public void updateBookStatus(String bookId, boolean status) {
        for (Book book : books) {
            if (book.getBookId().equals(bookId)) {
                book.setAvailable(status);
                return;
            }
        }
    }

    // Method to search books by title
    public List<Book> searchByTitle(String title) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                result.add(book);
            }
        }
        return result;
    }

    // Method to search books by author
    public List<Book> searchByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthorOfBook().equalsIgnoreCase(author)) {
                result.add(book);
            }
        }
        return result;
    }
}
