package assignment6.facadePattern;

public class BorrowRecord {
    private String bookId;
    private String title;
    private String borrowDate;
    private String returnDate;

    public BorrowRecord(String bookId){
        this.bookId = bookId;
    }
    public BorrowRecord(String bookId, String title, String borrowDate, String returnDate) {
        this.bookId = bookId;
        this.title = title;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    // Getters and setters for bookId, title, borrowDate, and returnDate

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    // Other methods as needed, such as toString() to represent the object as a string
}
