package assignment6.facadePattern;

import java.util.List;

public class LibraryFacadeImplementation implements LibraryFacade{
    private BookInventorySystem bookInventory;
    private UserManagementSystem userManagement;

    public LibraryFacadeImplementation(BookInventorySystem bookInventory, UserManagementSystem userManagement){
        this.bookInventory = bookInventory;
        this.userManagement = userManagement;
    }
    @Override
    public void borrowBook(String bookId, String userId) {
        if(bookInventory.isAvailable(bookId)){
            userManagement.borrowBook(bookId, userId);
            bookInventory.updateBookStatus(bookId, false);
        }
    }

    @Override
    public void returnBook(String bookId, String userId) {
        userManagement.returnBook(bookId, userId);
        bookInventory.updateBookStatus(bookId, true);
    }

    @Override
    public List<Book> searchBookByTitle(String title) {
        return bookInventory.searchByTitle(title);
    }

    @Override
    public List<Book> searchBookByAuthor(String author) {
        return bookInventory.searchByAuthor(author);
    }

    @Override
    public boolean isBookAvailable(String bookId) {
        return bookInventory.isAvailable(bookId);
    }

    @Override
    public void reserveBook(String bookId, String userId) {
        userManagement.reserveBook(bookId, userId);
    }

    @Override
    public List<BorrowRecord> getBorrowerHistory(String bookId) {
        return userManagement.getBorrowHistory(bookId);
    }
}
