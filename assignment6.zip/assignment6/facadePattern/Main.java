package assignment6.facadePattern;


import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create instances of BookInventorySystem and UserManagementSystem
        BookInventorySystem bookInventory = new BookInventorySystem();
        UserManagementSystem userManagement = new UserManagementSystem();

        // Create an instance of LibraryFacadeImplementation
        LibraryFacade library = new LibraryFacadeImplementation(bookInventory, userManagement);

        // Borrow a book
        String bookId = "123";
        String userId = "456";
        library.borrowBook(bookId, userId);
        System.out.println("Book borrowed successfully.");

        // Check if the book is available
        boolean isAvailable = library.isBookAvailable(bookId);
        System.out.println("Is book available? " + isAvailable);

        // Return the book
        library.returnBook(bookId, userId);
        System.out.println("Book returned successfully.");

        // Search for books by title
        String searchTitle = "Harry Potter";
        List<Book> booksByTitle = library.searchBookByTitle(searchTitle);
        System.out.println("Books with title '" + searchTitle + "':");
        for (Book book : booksByTitle) {
            System.out.println(book);
        }

        // Search for books by author
        String searchAuthor = "J.K. Rowling";
        List<Book> booksByAuthor = library.searchBookByAuthor(searchAuthor);
        System.out.println("Books by author '" + searchAuthor + "':");
        for (Book book : booksByAuthor) {
            System.out.println(book);
        }

        // Get borrower history for a book
        String bookIdToCheck = "456";
        List<BorrowRecord> borrowHistory = library.getBorrowerHistory(bookIdToCheck);
        System.out.println("Borrower history for book with ID '" + bookIdToCheck + "':");
        for (BorrowRecord record : borrowHistory) {
            System.out.println(record);
        }
    }
}
