package assignment6.facadePattern;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserManagementSystem {
    private Map<String, List<BorrowRecord>> userBorrowHistory;

    public UserManagementSystem() {
        // Initialize the user borrow history map
        this.userBorrowHistory = new HashMap<>();
    }

    // Method to handle borrowing a book by a user
    public void borrowBook(String bookId, String userId) {
        // Initialize user's borrow history if not present
        userBorrowHistory.putIfAbsent(userId, new ArrayList<>());
        // Add the borrow record to the user's borrow history
        userBorrowHistory.get(userId).add(new BorrowRecord(bookId));
    }

    // Method to handle returning a book by a user
    public void returnBook(String bookId, String userId) {
        // Get the user's borrow history
        List<BorrowRecord> borrowHistory = userBorrowHistory.get(userId);
        if (borrowHistory != null) {
            // Remove the borrow record for the returned book
            borrowHistory.removeIf(record -> record.getBookId().equals(bookId));
        }
    }

    // Method to handle reserving a book by a user
    public void reserveBook(String bookId, String userId) {
        // This method can be implemented as needed
        // For simplicity, let's assume reservation functionality is not implemented in this example
    }

    // Method to get the borrow history of a user for a specific book
    public List<BorrowRecord> getBorrowHistory(String userId) {
        // Get the user's borrow history
        List<BorrowRecord> borrowHistory = userBorrowHistory.get(userId);
        return borrowHistory != null ? new ArrayList<>(borrowHistory) : new ArrayList<>();
    }
}
