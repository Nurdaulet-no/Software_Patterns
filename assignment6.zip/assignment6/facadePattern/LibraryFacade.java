package assignment6.facadePattern;

import java.util.List;

public interface LibraryFacade {
    void borrowBook(String bookId, String userId);
    void returnBook(String bookId, String userId);
    List<Book> searchBookByTitle(String title);
    List<Book> searchBookByAuthor(String author);
    boolean isBookAvailable(String bookId);
    void reserveBook(String bookId, String userId);
    List<BorrowRecord> getBorrowerHistory(String bookId);
}

