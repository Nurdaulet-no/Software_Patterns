package assignment6.facadePattern;

public class Book {
    String bookId;
    String bookName;
    String authorOfBook;
    String title;
    String productionDate;
    boolean available;
    public Book(String bookId, String bookName, String authorOfBook){
        this.bookId = bookId;
        this.bookName = bookName;
        this.authorOfBook = authorOfBook;
    }
    public Book(String bookId, String bookName, String authorOfBook, boolean available){
        this.bookId = bookId;
        this.bookName = bookName;
        this.authorOfBook = authorOfBook;
        available = true;
    }
    public Book(String bookId, String bookName, String authorOfBook, String title, String productionDate){
        this.bookId = bookId;
        this.bookName = bookName;
        this.authorOfBook = authorOfBook;
        this.title = title;
        this.productionDate = productionDate;
    }

    public String getBookId() {
        return bookId;
    }
    public String getBookName() {
        return bookName;
    }
    public String getAuthorOfBook() {
        return authorOfBook;
    }

    public String getTitle() {
        return title != null ? title : "";
    }

    public void setAuthorOfBook(String authorOfBook) {
        this.authorOfBook = authorOfBook;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}
