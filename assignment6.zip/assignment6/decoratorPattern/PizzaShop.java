package assignment6.decoratorPattern;

public class PizzaShop {
    public static void main(String[] args) {
        Pizza pizza = new BasicPizza(); // Start with a basic pizza
        System.out.println("Basic Pizza Price: $" + pizza.getPrice());

        pizza = new PepperoniTopping(pizza); // Add pepperoni topping
        System.out.println("Price after adding Pepperoni: $" + pizza.getPrice());

        pizza = new MushroomTopping(pizza); // Add mushroom topping
        System.out.println("Price after adding Mushrooms: $" + pizza.getPrice());
    }
}

