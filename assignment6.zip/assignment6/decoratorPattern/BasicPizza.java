package assignment6.decoratorPattern;

public class BasicPizza implements Pizza{
    @Override
    public double getPrice() {
        return 8.00; // Base price of the pizza
    }
}
