package assignment6.decoratorPattern;

abstract class PizzaDecorator implements Pizza {
    protected Pizza decoratedPizza;

    public PizzaDecorator(Pizza pizza) {
        this.decoratedPizza = pizza;
    }

    @Override
    public double getPrice() {
        return decoratedPizza.getPrice(); // Returns the price of the pizza being decorated
    }
}
