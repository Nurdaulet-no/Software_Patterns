package assignment6.decoratorPattern;

public interface Pizza {
    double getPrice();
}
