package assignment6.adapterDesignPattern;

public class WeatherAPI_A {
    public double getTemperature() { // Temperature in Fahrenheit
        return 75.5;
    }

    public double getWindSpeed() { // Wind speed in miles per hour
        return 10.5;
    }

    public String getCondition() { // Weather condition description
        return "Sunny";
    }
}

class WeatherAPI_A_Adapter implements WeatherData {
    private WeatherAPI_A apiA;

    public WeatherAPI_A_Adapter(WeatherAPI_A apiA) {
        this.apiA = apiA;
    }

    @Override
    public double getTemperatureInCelsius() {
        return (apiA.getTemperature() - 32) * 5 / 9;
    }

    @Override
    public double getWindSpeedInKmH() {
        return apiA.getWindSpeed() * 1.60934;
    }

    @Override
    public String getWeatherCondition() {
        return apiA.getCondition();
    }
}

