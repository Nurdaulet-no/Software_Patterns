package assignment6.adapterDesignPattern;

public interface WeatherData {
    double getTemperatureInCelsius();
    double getWindSpeedInKmH();
    String getWeatherCondition();
}

