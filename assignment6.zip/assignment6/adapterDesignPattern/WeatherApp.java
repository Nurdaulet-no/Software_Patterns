package assignment6.adapterDesignPattern;

public class WeatherApp {
    public static void main(String[] args) {
        WeatherAPI_A apiA = new WeatherAPI_A();
        WeatherData adapterA = new WeatherAPI_A_Adapter(apiA);
        displayWeather(adapterA);

        WeatherAPI_B apiB = new WeatherAPI_B();
        WeatherData adapterB = new WeatherAPI_B_Adapter(apiB);
        displayWeather(adapterB);
    }

    public static void displayWeather(WeatherData weatherData) {
        System.out.println("Temperature in Celsius: " + weatherData.getTemperatureInCelsius());
        System.out.println("Wind Speed in Km/h: " + weatherData.getWindSpeedInKmH());
        System.out.println("Weather Condition: " + weatherData.getWeatherCondition());
    }
}

