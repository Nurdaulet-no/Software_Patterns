package assignment6.adapterDesignPattern;

public class WeatherAPI_B {
    public double getTempCelsius() { // Temperature in Celsius
        return 23.0;
    }

    public double getWindKmH() { // Wind speed in kilometers per hour
        return 17.0;
    }

    public String getCurrentWeather() { // Weather condition description
        return "Cloudy";
    }
}

class WeatherAPI_B_Adapter implements WeatherData {
    private WeatherAPI_B apiB;

    public WeatherAPI_B_Adapter(WeatherAPI_B apiB) {
        this.apiB = apiB;
    }

    @Override
    public double getTemperatureInCelsius() {
        return apiB.getTempCelsius();
    }

    @Override
    public double getWindSpeedInKmH() {
        return apiB.getWindKmH();
    }

    @Override
    public String getWeatherCondition() {
        return apiB.getCurrentWeather();
    }
}

