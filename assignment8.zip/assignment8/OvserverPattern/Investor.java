package assignment8.OvserverPattern;


import java.util.ArrayList;
import java.util.List;

public class Investor {
    private String name;
    private List<Stock> stocks;

    public Investor(String name) {
        this.name = name;
        this.stocks = new ArrayList<>();
    }

    public void update(Stock stock, double price) {
        System.out.println(name + " notified: " + stock.getSymbol() + " is now " + price);
    }

    public void addStock(Stock stock) {
        if (!stocks.contains(stock)) {
            stocks.add(stock);
            stock.registerInvestor(this);
        }
    }

    public void removeStock(Stock stock) {
        if (stocks.contains(stock)) {
            stocks.remove(stock);
            stock.unregisterInvestor(this);
        }
    }

    public String getName() {
        return name;
    }
}

