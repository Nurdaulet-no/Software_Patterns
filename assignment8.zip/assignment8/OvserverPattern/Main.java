package assignment8.OvserverPattern;


public class Main {
    public static void main(String[] args) {
        // Create some stocks
        Stock apple = new Stock("AAPL", 150);
        Stock google = new Stock("GOOG", 2800);

        // Create investors
        Investor alice = new Investor("Alice");
        Investor bob = new Investor("Bob");

        // Investors buy stocks
        alice.addStock(apple);
        bob.addStock(apple);
        bob.addStock(google);

        // Update stock prices
        apple.updatePrice(155);
        google.updatePrice(2850);
    }
}

