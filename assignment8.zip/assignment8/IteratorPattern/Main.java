package assignment8.IteratorPattern;

public class Main {
    public static void main(String[] args) {
        // Create a playlist and add some songs
        Playlist playlist = new PlaylistImpl();
        playlist.addSong(new Song("Bohemian Rhapsody", "Queen"));
        playlist.addSong(new Song("Imagine", "John Lennon"));
        playlist.addSong(new Song("Like a Rolling Stone", "Bob Dylan"));

        // Create an iterator for the playlist
        Iterator<Song> iterator = playlist.createIterator();

        // Iterate through the songs and print them
        System.out.println("Playlist:");
        while (iterator.hasNext()) {
            Song song = iterator.next();
            System.out.println(song);
        }
    }
}

