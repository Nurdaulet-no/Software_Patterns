package assignment8.IteratorPattern;

public interface Playlist {
    Iterator<Song> createIterator();
    void addSong(Song song);
}

