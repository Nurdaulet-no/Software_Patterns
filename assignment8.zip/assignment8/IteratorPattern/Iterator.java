package assignment8.IteratorPattern;

public interface Iterator<T> {
    boolean hasNext();
    T next();
}

