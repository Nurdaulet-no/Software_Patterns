package assignment7.proxyDesignPattern;

public class DocumentStorageProxy implements IDocumentStorage {
    private DocumentStorage documentStorage;

    public DocumentStorageProxy() {
        this.documentStorage = new DocumentStorage();
    }

    @Override
    public String fetchDocument(String docId, User user) {
        if (!authenticate(user) || !authorize(user, "fetch")) {
            throw new SecurityException("Access denied");
        }
        logAccess(user, "fetchDocument", docId);
        return documentStorage.fetchDocument(docId, user);
    }

    @Override
    public void uploadDocument(String content, User user) {
        if (!authenticate(user) || !authorize(user, "upload")) {
            throw new SecurityException("Access denied");
        }
        logAccess(user, "uploadDocument", content);
        documentStorage.uploadDocument(content, user);
    }

    @Override
    public String searchDocuments(String query, User user) {
        if (!authenticate(user) || !authorize(user, "search")) {
            throw new SecurityException("Access denied");
        }
        logAccess(user, "searchDocuments", query);
        return documentStorage.searchDocuments(query, user);
    }

    private boolean authenticate(User user) {
        // Simulate authentication logic
        return user != null && user.isAuthenticated();
    }

    private boolean authorize(User user, String operation) {
        // Simulate authorization logic
        return user.hasPermission(operation);
    }

    private void logAccess(User user, String operation, String detail) {
        // Log user activity
        System.out.println("User " + user.getName() + " performed " + operation + " on " + detail);
    }
}

