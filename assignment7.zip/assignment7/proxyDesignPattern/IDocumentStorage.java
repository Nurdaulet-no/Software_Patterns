package assignment7.proxyDesignPattern;

public interface IDocumentStorage {
    String fetchDocument(String docId, User user);
    void uploadDocument(String content, User user);
    String searchDocuments(String query, User user);
}

