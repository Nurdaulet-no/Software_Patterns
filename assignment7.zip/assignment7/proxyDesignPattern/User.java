package assignment7.proxyDesignPattern;

import java.util.Set;

public class User {
    private String name;
    private boolean authenticated;
    private Set<String> permissions;

    public User(String name, boolean authenticated, Set<String> permissions) {
        this.name = name;
        this.authenticated = authenticated;
        this.permissions = permissions;
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    public boolean hasPermission(String permission) {
        return permissions.contains(permission);
    }

    public String getName() {
        return name;
    }
}

