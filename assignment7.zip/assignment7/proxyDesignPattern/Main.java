package assignment7.proxyDesignPattern;

import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        // Create permissions for the authorized user
        HashSet<String> permissions = new HashSet<>();
        permissions.add("fetch");
        permissions.add("upload");
        permissions.add("search");

        // Create users
        User authorizedUser = new User("John Doe", true, permissions);
        User unauthorizedUser = new User("Jane Doe", true, new HashSet<>());

        // Create the proxy
        DocumentStorageProxy proxy = new DocumentStorageProxy();

        // Simulate document operations
        try {
            System.out.println("Attempting to fetch document with authorized user:");
            System.out.println(proxy.fetchDocument("doc123", authorizedUser));

            System.out.println("Attempting to upload document with authorized user:");
            proxy.uploadDocument("This is a new document content.", authorizedUser);

            System.out.println("Attempting to search documents with authorized user:");
            System.out.println(proxy.searchDocuments("report", authorizedUser));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            System.out.println("Attempting to fetch document with unauthorized user:");
            System.out.println(proxy.fetchDocument("doc123", unauthorizedUser));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
