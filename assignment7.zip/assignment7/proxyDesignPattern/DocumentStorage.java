package assignment7.proxyDesignPattern;

public class DocumentStorage implements IDocumentStorage {

    @Override
    public String fetchDocument(String docId, User user) {
        // Simulate fetching a document
        return "Document content for ID: " + docId;
    }

    @Override
    public void uploadDocument(String content, User user) {
        // Simulate uploading a document
        System.out.println("Document uploaded: " + content);
    }

    @Override
    public String searchDocuments(String query, User user) {
        // Simulate document search
        return "Search results for: " + query;
    }
}
