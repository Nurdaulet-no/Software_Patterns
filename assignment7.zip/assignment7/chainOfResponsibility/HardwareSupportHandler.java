package assignment7.chainOfResponsibility;

class HardwareSupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    @Override
    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleRequest(SupportRequest request) {
        if ("hardware".equals(request.getType())) {
            System.out.println("Handling hardware request #" + request.getId() + " with priority " + request.getPriority());
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        } else {
            System.out.println("No handler available for request #" + request.getId());
        }
    }
}

class SoftwareSupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    @Override
    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleRequest(SupportRequest request) {
        if ("software".equals(request.getType())) {
            System.out.println("Handling software request #" + request.getId() + " with priority " + request.getPriority());
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        } else {
            System.out.println("No handler available for request #" + request.getId());
        }
    }
}

class NetworkSupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    @Override
    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleRequest(SupportRequest request) {
        if ("network".equals(request.getType())) {
            System.out.println("Handling network request #" + request.getId() + " with priority " + request.getPriority());
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        } else {
            System.out.println("No handler available for request #" + request.getId());
        }
    }
}

