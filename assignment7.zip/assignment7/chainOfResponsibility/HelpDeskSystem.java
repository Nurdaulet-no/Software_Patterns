package assignment7.chainOfResponsibility;

public class HelpDeskSystem {
    public static void main(String[] args) {
        // Create handlers
        SupportHandler hardwareHandler = new HardwareSupportHandler();
        SupportHandler softwareHandler = new SoftwareSupportHandler();
        SupportHandler networkHandler = new NetworkSupportHandler();

        // Set the chain of responsibility
        hardwareHandler.setNextHandler(softwareHandler);
        softwareHandler.setNextHandler(networkHandler);

        // Create requests
        SupportRequest hardwareRequest = new SupportRequest(1, "Printer is not working", "hardware", 2);
        SupportRequest softwareRequest = new SupportRequest(2, "Cannot install software", "software", 1);
        SupportRequest networkRequest = new SupportRequest(3, "Internet connection is down", "network", 3);

        // Handle requests
        hardwareHandler.handleRequest(hardwareRequest);
        hardwareHandler.handleRequest(softwareRequest);
        hardwareHandler.handleRequest(networkRequest);
    }
}

